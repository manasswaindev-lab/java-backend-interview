package com.challenge.orderservice.controller;

import com.challenge.orderservice.service.OrderService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping("/total-revenue")
    public double getTotalRevenue() {
        return orderService.calculateTotalRevenue();    
    }

    @GetMapping("/top-spent-customers")
    public List<String> getTopSpentCustomers(@RequestParam(defaultValue = "10") int n) {
        return orderService.getTopSpentCustomers(n);
    }

    @GetMapping("/group-by-customer")
    public Map<String, List<Order>> groupOrdersByCustomer() {
        return orderService.groupOrdersByCustomer();
    }


}
