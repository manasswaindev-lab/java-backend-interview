package com.challenge.orderservice.service;

import com.challenge.orderservice.repository.OrderRepository;
import com.challenge.orderservice.entity.Order;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

@Service
public class OrderService {

    private final OrderRepository orderRepository;

    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public double calculateTotalRevenue() {

        return orderRepository.findAll()
                .stream()
                .mapToDouble(order -> order.getItems().stream().mapToDouble(item -> item.getPrice() * item.getQuantity()).sum())
                .sum();
    }

    public Map<String, List<Order>> groupOrdersByCustomer() {

        Map<String, List<Order>> ordersByCustomer = orderRepository.findAll()
                .stream()
                .collect(Collectors.groupingBy(Order::getCustomerId));
        return ordersByCustomer;
    }

    public List<String> getTopSpentCustomers(int n) {
        List<String> topCustomers = orderRepository.findAll()
                .stream()
                .collect(Collectors.groupingBy(Order::getCustomerId, Collectors.summingDouble(order -> order.getItems().stream().mapToDouble(item -> item.getPrice() * item.getQuantity()).sum())))
                .entrySet()
                .stream()
                .sorted(Map.Entry.<String, Double>comparingByValue().reversed())
                .limit(n)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
        return topCustomers;
    }
}
