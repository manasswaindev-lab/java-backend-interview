package main.java.com.challenge.orderservice.security;
import java.beans.BeanProperty;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityConfig {
    @Bean
    public securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf().disable()
            .authorizeRequests()
            .antMatchers("/api/orders/**").permitAll()
            .anyRequest().authenticated();
    
        return http.build();
    }
}
