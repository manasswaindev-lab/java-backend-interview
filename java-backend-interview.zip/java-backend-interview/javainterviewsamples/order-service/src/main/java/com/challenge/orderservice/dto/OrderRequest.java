package main.java.com.challenge.orderservice.dto;

public class OrderRequest {
    
    @Size(min = 1, message = "Product ID must not be empty")
    private String productId;

    @Min(value = 1, message = "Quantity must be a positive integer")
    private int quantity;
    
    @Min(value = 0, message = "Price must be a non-negative value")
    private double price;
    
    @Size(min = 1, message = "Customer ID must not be empty")
    private String customerId;
}
