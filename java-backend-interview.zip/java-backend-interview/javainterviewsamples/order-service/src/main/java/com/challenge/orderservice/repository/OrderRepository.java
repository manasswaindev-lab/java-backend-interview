package com.challenge.orderservice.repository;

import com.challenge.orderservice.entity.Order;
import com.challenge.orderservice.entity.OrderItem;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderRepository extends JpaRepository<Order, String> {

    List<Order> findByCustomerId(String customerId);

    List<Order> findByStatus(String status);

    List<Order> findByCustomerIdAndStatus(String customerId, String status);

    List<Order> findByOrderId(String orderId);

    List<OrderItem> findByQuantity(int quantity);

    List<OrderItem> findByPrice(double price);

    List<OrderItem> findByName(String name);

    List<Order> findAll(String customerId);

    List<Order> findAll(List<OrderItem> items);
}
