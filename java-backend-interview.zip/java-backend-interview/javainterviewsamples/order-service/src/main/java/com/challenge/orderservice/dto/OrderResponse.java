package main.java.com.challenge.orderservice.dto;

public class OrderResponse {
    
}
