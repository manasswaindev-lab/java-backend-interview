package com.challenge.orderservice.entity;

import jakarta.persistence.*;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "orders")
public class Order {
    @Id
    private String orderId;
    private String customerId;
    private String status;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id")
    private List<OrderItem> items;

    // TODO: Candidate must add necessary boilerplate constructors, getters, setters


    public Order() {
    }

    public Order(String orderId, String customerId, String status, List<OrderItem> items) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.status = status;
        this.items = items;
    }

    public String getOrderId() {
        return this.orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getCustomerId() {
        return this.customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<OrderItem> getItems() {
        return this.items;
    }

    public void setItems(List<OrderItem> items) {
        this.items = items;
    }

    public Order orderId(String orderId) {
        setOrderId(orderId);
        return this;
    }

    public Order customerId(String customerId) {
        setCustomerId(customerId);
        return this;
    }

    public Order status(String status) {
        setStatus(status);
        return this;
    }

    public Order items(List<OrderItem> items) {
        setItems(items);
        return this;
    }

    @Override
    public boolean equals(Object o) {
      return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderId, customerId, status, items);
    }

    @Override
    public String toString() {
        return "{" +
            " orderId='" + getOrderId() + "'" +
            ", customerId='" + getCustomerId() + "'" +
            ", status='" + getStatus() + "'" +
            ", items='" + getItems() + "'" +
            "}";
    }
    
}
