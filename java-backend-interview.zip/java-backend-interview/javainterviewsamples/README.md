Sample Java
